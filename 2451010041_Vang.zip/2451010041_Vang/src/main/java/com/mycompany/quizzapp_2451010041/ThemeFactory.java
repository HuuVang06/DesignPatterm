/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.quizzapp_2451010041;

/**
 *
 * @author admin
 */
public interface ThemeFactory {

    String getBackgroundStyle();

    String getButtonStyle();

    String getTitleStyle();
    
    String getComboBoxStyle();

}
