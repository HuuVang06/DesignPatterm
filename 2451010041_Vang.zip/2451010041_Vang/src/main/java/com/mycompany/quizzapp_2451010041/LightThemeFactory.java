/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizzapp_2451010041;

/**
 *
 * @author admin
 */
public class LightThemeFactory implements ThemeFactory {

    @Override
    public String getBackgroundStyle() {
        return "-fx-background-color: #ffffff; -fx-padding: 20;";
    }

    @Override
    public String getButtonStyle() {
        return "-fx-background-color: #e0e0e0; -fx-text-fill: black; -fx-font-size: 16px; "
                + "-fx-font-weight: bold; -fx-background-radius: 5;";
    }

    @Override
    public String getTitleStyle() {
        return "-fx-font-size: 32px; -fx-font-weight: bold; -fx-text-fill: #000000; "
                + "-fx-effect: dropshadow(three-pass-box, #FFFF00, 3, 1.0, 0, 0);";
    }

    @Override
    public String getComboBoxStyle() {
        return "-fx-background-color: #e0e0e0; -fx-text-fill: black; -fx-font-weight: bold;";
    }

}
