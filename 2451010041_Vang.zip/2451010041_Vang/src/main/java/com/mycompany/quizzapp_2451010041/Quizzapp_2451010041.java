/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizzapp_2451010041;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

/**
 *
 * @author admin
 */
public class Quizzapp_2451010041 extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        Label title = new Label("QUIZ APP");

        Button btnQuestion = new Button("Quản lý câu hỏi");
        Button btnPractice = new Button("Luyện tập");
        Button btnExam = new Button("Luyện thi");

        btnQuestion.setPrefWidth(280);
        btnPractice.setPrefWidth(280);
        btnExam.setPrefWidth(280);

        btnQuestion.setOnAction(e -> {
            MyAlert.getInstance().showMessage("Đây là chức năng quản lý câu hỏi");
        });

        btnPractice.setOnAction(e -> {
            MyAlert.getInstance().showMessage("Đây là chức năng luyện tập");
        });

        btnExam.setOnAction(e -> {
            MyAlert.getInstance().showMessage("Đây là chức năng luyện thi");
        });

        ComboBox<String> themeChooser = new ComboBox<>();
        themeChooser.getItems().addAll("DEFAULT_THEME", "DARK_THEME", "LIGHT_THEME");
        themeChooser.setValue("DEFAULT_THEME");
        themeChooser.setPrefWidth(280);

        VBox root = new VBox(15);
        root.setAlignment(Pos.CENTER);
        root.getChildren().addAll(title, btnQuestion, btnPractice, btnExam, themeChooser);

        applyTheme(new DefaultThemeFactory(), root, title, themeChooser, btnQuestion, btnPractice, btnExam);

        themeChooser.setOnAction(e -> {
            String selectedTheme = themeChooser.getValue();
            ThemeFactory factory;

            switch (selectedTheme) {
                case "DARK_THEME":
                    factory = new DarkThemeFactory();
                    break;
                case "LIGHT_THEME":
                    factory = new LightThemeFactory();
                    break;
                default:
                    factory = new DefaultThemeFactory();
                    break;
            }
            applyTheme(factory, root, title, themeChooser, btnQuestion, btnPractice, btnExam);
        });

        Scene scene = new Scene(root, 400, 450);
        stage.setScene(scene);
        stage.setTitle("Quiz App - Design Patterns");
        stage.show();
    } 

    private void applyTheme(ThemeFactory factory, VBox root, Label title, ComboBox<String> combo, Button... buttons) {
        root.setStyle(factory.getBackgroundStyle());
        title.setStyle(factory.getTitleStyle());
        combo.getEditor().setStyle("-fx-text-fill: " + (factory instanceof DefaultThemeFactory ? "#0055ff;" : "white;"));
        for (Button btn : buttons) {
            btn.setStyle(factory.getButtonStyle());
        }
    }
}