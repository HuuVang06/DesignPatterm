/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.mycompany.quizzapp_2451010041;

/**
 *
 * @author admin
 */
public enum ThemeType {
    DARK_THEME,
    LIGHT_THEME,
    DEFAULT_THEME
}
