/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizzapp_2451010041;

import java.util.Optional;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

/**
 *
 * @author admin
 */
public class MyAlert {

    private static MyAlert instance;
    private Alert alert;

    public MyAlert() {
        alert = new Alert(Alert.AlertType.INFORMATION);
    }

    public static MyAlert getInstance() {
        if (instance == null) {
            instance = new MyAlert();
        }

        return instance;
        
    }

    public Optional<ButtonType> showMessage (String message){
        alert.setAlertType(Alert.AlertType.INFORMATION);
        alert.setTitle("Quiz app");
        alert.setHeaderText("Thông báo");
        alert.setContentText(message);
        
        return alert.showAndWait();
    }
}
