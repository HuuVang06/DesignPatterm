/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizzapp_2451010041;

/**
 *
 * @author admin
 */
public class DefaultThemeFactory implements ThemeFactory {

    @Override
    public String getBackgroundStyle() {
        return "-fx-background-color: #F4F4F4;";
    }

    @Override
    public String getButtonStyle() {
        return "-fx-background-color: #000099; -fx-text-fill: white; -fx-font-size: 16px; "
                + "-fx-font-weight: bold; -fx-background-radius: 5;";
    }

    @Override
    public String getTitleStyle() {
        return "-fx-font-size: 32px; -fx-font-weight: bold; -fx-text-fill: #FF0000; "
                + "-fx-effect: dropshadow(three-pass-box, #FFFF00, 3, 1.0, 0, 0);";
    }

    @Override
    public String getComboBoxStyle() {
        return "-fx-background-color: #0000FF; -fx-text-fill: #00FFFF; -fx-font-weight: bold;";
    }

}
